package Composite;

public interface PanelManager extends Component {
    void adaugaComponenta(Component componenta);
    void eliminaComponenta(Component componenta);
}
